package com.example.vacaciones

class Holiday( val name: String, val date: String, val type: String, val region: String, val description: String) {
}