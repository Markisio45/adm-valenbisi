package com.example.vacaciones

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class HolidayAdapter( private val holidayList:List<Holiday>) : RecyclerView.Adapter<HolidayViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): HolidayViewHolder {
//        val layout = LayoutInflater.from( parent.context).inflate(R.layout.holiday_item, parent, false)
        val layout = LayoutInflater.from( parent.context).inflate(R.layout.holiday_card, parent, false)
        return HolidayViewHolder( layout)
    }

    override fun onBindViewHolder(
        holder: HolidayViewHolder,
        position: Int
    ) {
        val item = holidayList[position]
        holder.render( item)
    }

    override fun getItemCount(): Int = holidayList.size

}