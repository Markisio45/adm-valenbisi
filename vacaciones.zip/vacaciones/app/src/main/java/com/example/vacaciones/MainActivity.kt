package com.example.vacaciones

import android.content.Context
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        var holidays: List<Holiday> = getHolidaysList( this)

        initRecyclerView( holidays)
    }

    fun initRecyclerView( holidays : List<Holiday>){
        val recyclerView: RecyclerView = findViewById<RecyclerView>(R.id.holidayList)
        recyclerView.layoutManager = LinearLayoutManager( this)
        recyclerView.adapter = HolidayAdapter( holidays)
    }
}

fun getHolidaysList(context: Context): List<Holiday> {
    val holidaysList = mutableListOf<Holiday>()
    val jsonString = readJsonFromRaw(context, R.raw.holidays)
    try {
        val jsonArray = JSONArray(jsonString)
        for (i in 0 until jsonArray.length()) {
            //TODO read each item and create a Holiday instance
            var item = jsonArray.getJSONObject(i)
            var name: String = item.getString("name")
            var date: String = item.getString("date")
            var type: String = item.getString( "type")
            var region: String = item.getString( "region")
            var description: String = item.getString("description")
            holidaysList.add(Holiday(name, date, type, region, description))
        }
    } catch (e: JSONException) {
        e.printStackTrace()
    }
    return holidaysList
}

fun readJsonFromRaw(context: Context, resId: Int): String {
    val inputStream = context.resources.openRawResource(resId)
    val reader = BufferedReader(InputStreamReader(inputStream))
    return reader.use { it.readText() }
}