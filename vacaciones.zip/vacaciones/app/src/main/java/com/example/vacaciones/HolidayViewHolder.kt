package com.example.vacaciones

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HolidayViewHolder( view : View) : RecyclerView.ViewHolder( view) {

    val nameTV = view.findViewById<TextView>(R.id.name)
    val dateTV = view.findViewById<TextView>(R.id.date)
    val typeTV = view.findViewById<TextView>(R.id.type)
    val regionTV = view.findViewById<TextView>(R.id.region)
    val descriptionTV = view.findViewById<TextView>(R.id.description)


    fun render( holiday: Holiday){
        nameTV.text = holiday.name
        dateTV.text = holiday.date
        typeTV.text = holiday.type
        regionTV.text = holiday.region
        descriptionTV.text = holiday.description

    }
}